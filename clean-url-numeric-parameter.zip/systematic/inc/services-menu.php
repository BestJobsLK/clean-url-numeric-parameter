<h2>Our Services</h2>
<ul class="services">
	<li> <a href="/systematic/services/bookkeeping" <?php echo ($sub_page == 'bookkeeping') ? $active : ''; ?>>Accounting &amp; Bookkeeping</a></li>
	<li> <a href="/systematic/services/reconciliation"  <?php echo ($sub_page == 'reconciliation') ? $active : ''; ?>>Accounts Reconciliation</a></li>
	<li> <a href="/systematic/services/reporting"  <?php echo ($sub_page == 'reporting') ? $active : ''; ?>>Financial Reporting</a></li>
	<li> <a href="/systematic/services/cfo"  <?php echo ($sub_page == 'cfo-services') ? $active : ''; ?>>CFO Services</a></li>
</ul>