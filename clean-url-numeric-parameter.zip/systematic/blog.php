<?php
	// connecting to the database
	$connection = mysqli_connect('localhost', 'root', '', 'systematic');
	// checking the connection
	if ( !$connection ) {
		die("Error - database connection failed");
	}
	// checking if url parameter is present
	if ( isset($_GET['blog_id']) ) {
		$blog_id = mysqli_real_escape_string($connection, $_GET['blog_id']);
		$query   = "SELECT * FROM blog WHERE blog_id = {$blog_id} LIMIT 1";		
	} else {
		// getting the latest blog post
		$query   = "SELECT * FROM blog ORDER BY blog_id DESC LIMIT 1";
	}
	// executing the query
	$result_set = mysqli_query($connection, $query);
	// checking if the query is successful
	if ( $result_set ) {
		if ( mysqli_num_rows($result_set) == 1 ) {
			// prepare to display the record
			$blog_post = mysqli_fetch_assoc($result_set);
			$blog_title = stripslashes($blog_post['blog_title']);
			$blog_date = stripslashes($blog_post['blog_date']);
			$blog_text = stripslashes($blog_post['blog_text']);
		} else {
			// no records found. going back to home page
			header('Location: /systematic/?error=blog-not-found');
		}
	} else {
		// database query failed		
		echo $query; die();
		header('Location: index.php?error=database-query-failed');
	}
	// preparing a list of previous posts
	$query  = "SELECT blog_id, blog_short_title FROM blog ORDER BY blog_id LIMIT 10";
	$result_set = mysqli_query($connection, $query);
	$blog_nav = '<ul>';
	if ( $result_set ) {
		if ( mysqli_num_rows($result_set) > 0 ) {
			while ( $result = mysqli_fetch_assoc($result_set) ) {
				$blog_nav .= '<li><a href="/systematic/blog/' . $result['blog_id'] . '">' . $result['blog_short_title'] . '</a></li>';
			}
		} else {
			// no records found			
		}		
	} else {
		// datbase query failed		
	}
	$blog_nav .= '</ul>';
?>
<?php $page = 'blog'; ?>
<?php $title = 'Blog - '; ?>
<?php require_once('inc/header.php') ?>

		<div class="content clearfix">
			<div class="blog-post">
				<h1><?php echo $blog_title; ?></h1>
				<p class="blog-date-posted">DATE POSTED: <?php echo $blog_date; ?></p>
				<?php echo $blog_text; ?>
			</div> <!-- .blog-post -->

			<div class="blog-nav">
				<h2>PREVIOUS POSTS</h2>
				<?php echo stripslashes($blog_nav); ?>
			</div> <!-- .blog-nav -->
		</div> <!-- .content -->

		

<?php require_once('inc/footer.php'); ?>