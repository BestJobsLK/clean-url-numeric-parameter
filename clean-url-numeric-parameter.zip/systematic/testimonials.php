<?php $page = 'testimonials'; ?>
<?php $title = 'Testimonials - '; ?>
<?php require_once('inc/header.php') ?>

		<div class="content clearfix">
			<div class="colleft clearfix">
				<div class="quote">
					<i class="fa fa-quote-left fa-3x" aria-hidden="true"></i>
					<h3>Tommy Tanker - CEO</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere.</p>
					<a href="#">View This Project &raquo;</a>
				</div> <!-- quote -->
				<div class="quote">
					<i class="fa fa-quote-left fa-3x" aria-hidden="true"></i>
					<h3>Tommy Tanker - CEO</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere.</p>
					<a href="#">View This Project &raquo;</a>
				</div> <!-- quote -->
				<div class="quote">
					<i class="fa fa-quote-left fa-3x" aria-hidden="true"></i>
					<h3>Tommy Tanker - CEO</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere.</p>
					<a href="#">View This Project &raquo;</a>
				</div> <!-- quote -->
			</div> <!-- .colleft -->
			<div class="colright clearfix">
				<div class="quote">
					<i class="fa fa-quote-left fa-3x" aria-hidden="true"></i>
					<h3>Tommy Tanker - CEO</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere.</p>
					<a href="#">View This Project &raquo;</a>
				</div> <!-- quote -->
				<div class="quote">
					<i class="fa fa-quote-left fa-3x" aria-hidden="true"></i>
					<h3>Tommy Tanker - CEO</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere.</p>
					<a href="#">View This Project &raquo;</a>
				</div> <!-- quote -->
				<div class="quote">
					<i class="fa fa-quote-left fa-3x" aria-hidden="true"></i>
					<h3>Tommy Tanker - CEO</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere.</p>
					<a href="#">View This Project &raquo;</a>
				</div> <!-- quote -->
			</div> <!-- .colright -->
		</div> <!-- .content -->

		

<?php require_once('inc/footer.php'); ?>