<?php $page = 'home'; ?>
<?php $title = ''; ?>
<?php require_once('inc/header.php') ?>

		<div class="slideshow cycle-slideshow"
			data-cycle-fx="scrollHorz"
			data-cycle-slides="> div">
			
			<div class="intro clearfix">
				
				<div class="introimage">
					<img src="img/accountant.jpg" alt="Accountant">
				</div> <!-- .introimage -->

				<div class="introtext">
					<h1>A Huge <br>Title Here</h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur, nostrum ut amet cum in delectus explicabo ipsam molestiae velit, non repudiandae repellat veritatis asperiores quam perferendis molestias officia quibusdam dolorum.</p>
					<a href="#">Read More &raquo;</a>
				</div> <!-- .introtext -->
			
			</div> <!-- .intro -->

			<div class="intro clearfix">
				
				<div class="introimage">
					<img src="img/accountant-2.jpg" alt="Accountant">
				</div> <!-- .introimage -->

				<div class="introtext">
					<h1>Second <br>Title Here</h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur, nostrum ut amet cum in delectus explicabo ipsam molestiae velit, non repudiandae repellat veritatis asperiores quam perferendis molestias officia quibusdam dolorum.</p>
					<a href="#">Read More &raquo;</a>
				</div> <!-- .introtext -->
			
			</div> <!-- .intro -->

			<div class="intro clearfix">
				
				<div class="introimage">
					<img src="img/accountant-3.jpg" alt="Accountant">
				</div> <!-- .introimage -->

				<div class="introtext">
					<h1>The Third <br>Title Here</h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur, nostrum ut amet cum in delectus explicabo ipsam molestiae velit, non repudiandae repellat veritatis asperiores quam perferendis molestias officia quibusdam dolorum.</p>
					<a href="#">Read More &raquo;</a>
				</div> <!-- .introtext -->
			
			</div> <!-- .intro -->

		</div> <!-- .slideshow -->

		<div class="homecontent clearfix">
			<div class="home-col">
				<h2>A Little About Us</h2>
				<img src="img/about-us.jpg" alt="About Us">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt deleniti necessitatibus quasi, cumque corrupti dolorum ad voluptatem ea corporis numquam, maiores nam. </p>
				<p>Placeat earum consequatur, consequuntur itaque quas eveniet rem.</p>
				<a href="#">Read More About Us &raquo;</a>
			</div> <!-- home-col -->

			<div class="home-col">
				<h2>Some of Our Services</h2>
				<div class="services">
					<img src="img/services/statistics-market-icon.png" alt="Service">
					<h3>Service Name</h3>
					<p>A brief description about each service goes here...</p>
				</div> <!-- services -->

				<div class="services">
					<img src="img/services/certificate-icon.png" alt="Service">
					<h3>Service Name</h3>
					<p>A brief description about each service goes here...</p>
				</div> <!-- services -->

				<div class="services">
					<img src="img/services/dollar-rotation-icon.png" alt="Service">
					<h3>Service Name</h3>
					<p>A brief description about each service goes here...</p>
				</div> <!-- services -->

				<div class="services">
					<img src="img/services/lock-icon.png" alt="Service">
					<h3>Service Name</h3>
					<p>A brief description about each service goes here...</p>
				</div> <!-- services -->

				<a href="#">View All Of Our Services &raquo;</a>

			</div> <!-- home-col -->
			
			<div class="home-col">
				<h2>What Our Clients Say</h2>

				<div class="quote">
					<i class="fa fa-quote-left fa-3x" aria-hidden="true"></i>
					<h3>Tommy Tanker - CEO</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere.</p>
					<a href="#">View This Project &raquo;</a>
				</div> <!-- quote -->

				<div class="quote">
					<i class="fa fa-quote-left fa-3x" aria-hidden="true"></i>
					<h3>Tommy Tanker - CEO</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere.</p>
					<a href="#">View This Project &raquo;</a>
				</div> <!-- quote -->
			</div> <!-- home-col -->
		</div> <!-- homecontent -->

<?php require_once('inc/footer.php'); ?>