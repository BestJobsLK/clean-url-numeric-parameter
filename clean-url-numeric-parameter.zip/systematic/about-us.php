<?php $page = 'about'; ?>
<?php $title = 'About Us - '; ?>
<?php require_once('inc/header.php') ?>

		<div class="content clearfix">
			<div class="colleft clearfix">
				<h2>History</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem ducimus animi labore totam est optio, odio repudiandae iure officiis esse vero architecto eligendi, vitae error similique dolorem neque unde incidunt.</p>
				<p>Quam dolorum neque ullam dicta velit in accusantium cumque quaerat, ea laudantium facilis. Nihil, amet accusamus quia modi laborum architecto perferendis distinctio non pariatur. Explicabo architecto placeat magnam cumque dolore.</p>
				<p>Earum libero nobis dolor, eos saepe eum quo animi iste. Distinctio mollitia necessitatibus, pariatur amet architecto esse eaque non consectetur. Animi omnis architecto iure, consectetur sequi saepe perferendis, enim sed.</p>
			</div> <!-- .colleft -->
			<div class="colright clearfix">
				<h2>Mission</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur, minima cumque nulla unde accusamus doloribus ipsam nisi aliquid a vitae dolorum necessitatibus molestiae sunt assumenda, magni dignissimos consequuntur dolorem voluptatum.</p>
				<h2>Vision</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum itaque nam facere praesentium vel? Ratione minima culpa, earum tempora maiores doloribus. Maxime fuga aliquid nostrum reiciendis quibusdam voluptatibus aut vitae!</p>
			</div> <!-- .colright -->
		</div> <!-- .content -->

		

<?php require_once('inc/footer.php'); ?>